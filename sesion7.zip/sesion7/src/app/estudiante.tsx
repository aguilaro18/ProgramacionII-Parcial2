import { ThemedText } from '@/components/themed-text';
import { ThemedView } from '@/components/themed-view';
import { BottomTabInset, MaxContentWidth, Spacing } from '@/constants/theme';
import { supabase } from '@/database/supabase';
import { useTheme } from '@/hooks/use-theme';
import { Estudiante } from '@/models/Estudiante';
import { useEffect, useState } from 'react';
import {
  Alert,
  FlatList,
  Modal,
  Pressable,
  StyleSheet,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

type estudiante = {
  id: number;
  nombre: string;
  carnet: string;
  carrera: string;
  created_at: string;
};

export default function estudianteScreen() {
  const theme = useTheme();

  const [estudiante, setEstudiante] = useState<estudiante[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalVisible, setModalVisible] = useState(false);
  const [estudianteEditando, setEstudianteEditando] = useState<estudiante | null>(null);
  const [nombre, setNombre] = useState('');
  const [carnet, setCarnet] = useState('');
  const [carrera, setCarrera] = useState('');
  const [created_at, setCreated_at] = useState('');
  const [guardando, setGuardando] = useState(false);

  const cargarEstudiante = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('estudiante').select('*').order('id');

      if (error) {
        Alert.alert('Ha ocurrido un error', error.message);
        return;
      }

      setEstudiante((data ?? []) as estudiante[]);
    } catch (err) {
      Alert.alert('Ha ocurrido un error', err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    cargarEstudiante();
  }, []);

  const abrirNuevo = () => {
    setEstudianteEditando(null);
    setNombre('');
    setCarnet('');
    setCarrera('');
    setCreated_at('');
    setModalVisible(true);
  };

  const abrirEdicion = (item: Estudiante) => {
    setEstudianteEditando(item);
    setNombre(item.nombre);
    setCarnet(item.carnet);
    setCarrera(String(item.carrera));
    setCreated_at(item.created_at);
    setModalVisible(true);
  };

  const guardarEstudiante = async () => {
    if (!nombre.trim() || !carnet.trim()) {
      Alert.alert('Datos incompletos', 'El nombre y el carnet son obligatorios.');
      return;
    }

    const precioNum = Number(carnet);
    const stockNum = Number(created_at);

    if (Number.isNaN(precioNum) || precioNum < 0 || Number.isNaN(stockNum) || stockNum < 0) {
      Alert.alert('Valores inválidos', 'El precio y el stock deben ser números iguales o mayores a 0.');
      return;
    }

    setGuardando(true);
    try {
      const datos = {
        nombre: nombre.trim(),
        carnet: carnet.trim(),
        carrera: carrera.trim(),

      };

      const resultado = estudianteEditando
        ? await supabase.from('estudiante').update(datos).eq('id', estudianteEditando.id)
        : await supabase.from('estudiante').insert(datos);

      if (resultado.error) {
        Alert.alert('Ha ocurrido un error', resultado.error.message);
        return;
      }

      setModalVisible(false);
      cargarEstudiante();
    } catch (err) {
      Alert.alert('Ha ocurrido un error', err instanceof Error ? err.message : String(err));
    } finally {
      setGuardando(false);
    }
  };

  const eliminarEstudiante = async (estudiante: Estudiante) => {
    try {
      const { error } = await supabase.from('estudiante').delete().eq('id', estudiante.id);

      if (error) {
        Alert.alert('Ha ocurrido un error', error.message);
        return;
      }

      setEstudiante((car) => car.filter((item) => item.id !== estudiante.id));
    } catch (err) {
      Alert.alert('Ha ocurrido un error', err instanceof Error ? err.message : String(err));
    }
  };

  const confirmarEliminacion = (estudiante: Estudiante) => {
    if (typeof window !== 'undefined' && typeof window.confirm === 'function') {
      if (window.confirm(`¿Deseas eliminar "${estudiante.nombre}"?`)) {
        eliminarEstudiante(estudiante);
      }
      return;
    }

    Alert.alert('Eliminar estudiante', `¿Deseas eliminar "${estudiante.nombre}"?`, [
      { text: 'Cancelar', style: 'cancel' },
      { text: 'Eliminar', style: 'destructive', onPress: () => eliminarEstudiante(estudiante) },
    ]);
  };

  const renderItem = ({ item }: { item: Estudiante }) => (
    <ThemedView type="backgroundElement" style={styles.card}>
      <ThemedView type="backgroundElement" style={styles.cardInfo}>
        <ThemedText type="smallBold">{item.nombre}</ThemedText>
        <ThemedText type="small" themeColor="textSecondary">
          {item.carrera} · carr: {item.carrera}
        </ThemedText>
        <ThemedText type="smallBold">Q{item.carrera}</ThemedText>
      </ThemedView>

      <ThemedView type="backgroundElement" style={styles.cardActions}>
        <Pressable style={({ pressed }) => pressed && styles.pressed} onPress={() => abrirEdicion(item)}>
          <ThemedView type="backgroundSelected" style={styles.editButton}>
            <ThemedText type="small" style={styles.editButtonText}>
              Editar
            </ThemedText>
          </ThemedView>
        </Pressable>

        <Pressable style={({ pressed }) => pressed && styles.pressed} onPress={() => confirmarEliminacion(item)}>
          <ThemedView style={styles.deleteButton}>
            <ThemedText type="small" style={styles.deleteButtonText}>
              Eliminar
            </ThemedText>
          </ThemedView>
        </Pressable>
      </ThemedView>
    </ThemedView>
  );

  return (
    <ThemedView style={styles.container}>
      <SafeAreaView style={styles.safeArea}>
        <ThemedView style={styles.header}>
          <ThemedText type="subtitle"><Estudiantes></Estudiantes></ThemedText>
          <Pressable style={({ pressed }) => pressed && styles.pressed} onPress={abrirNuevo}>
            <ThemedView type="backgroundSelected" style={styles.newEstudianteButton}>
              <ThemedText type="small" style={styles.editButtonText}>
                + Nuevo estudiante
              </ThemedText>
            </ThemedView>
          </Pressable>
        </ThemedView>

        {loading ? (
          <ThemedText type="small" themeColor="textSecondary" style={styles.emptyText}>
            Cargando estudiantes…
          </ThemedText>
        ) : estudiante.length === 0 ? (
          <ThemedText type="small" themeColor="textSecondary" style={styles.emptyText}>
            No hay estudiantes registrados.
          </ThemedText>
        ) : (
          <FlatList
            data={estudiantes}
            keyExtractor={(item) => String(item.id)}
            renderItem={renderItem}
            contentContainerStyle={styles.listContent}
          />
        )}
      </SafeAreaView>

      <Modal
        visible={modalVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <ThemedView type="backgroundElement" style={styles.modalCard}>
            <ThemedText type="subtitle">
              {estudianteEditando ? 'Editar producto' : 'Nuevo estudiante'}
            </ThemedText>

            <ThemedView type="backgroundElement" style={styles.field}>
              <ThemedText type="smallBold">Nombre</ThemedText>
              <TextInput
                style={[styles.input, { backgroundColor: theme.background, color: theme.text }]}
                value={nombre}
                onChangeText={setNombre}
                placeholder="Ej. Laptop Gamer"
                placeholderTextColor={theme.textSecondary}
              />
            </ThemedView>

            <ThemedView type="backgroundElement" style={styles.field}>
              <ThemedText type="smallBold">Proveedor</ThemedText>
              <TextInput
                style={[styles.input, { backgroundColor: theme.background, color: theme.text }]}
                value={carnet}
                onChangeText={setCarnet}
                placeholder="Ej. Compugangas"
                placeholderTextColor={theme.textSecondary}
              />
            </ThemedView>

            <ThemedView type="backgroundElement" style={styles.field}>
              <ThemedText type="smallBold">Precio (Q)</ThemedText>
              <TextInput
                style={[styles.input, { backgroundColor: theme.background, color: theme.text }]}
                value={carrera}
                onChangeText={setCarrera}
                placeholder="Ej. 2500.75"
                placeholderTextColor={theme.textSecondary}
                keyboardType="numeric"
              />
            </ThemedView>

            <ThemedView type="backgroundElement" style={styles.field}>
              <ThemedText type="smallBold">Stock</ThemedText>
              <TextInput
                style={[styles.input, { backgroundColor: theme.background, color: theme.text }]}
                value={created_at}
                onChangeText={created_at}
                placeholder="Ej. 10"
                placeholderTextColor={theme.textSecondary}
                keyboardType="number-pad"
              />
            </ThemedView>

            <Pressable disabled={guardando} style={({ pressed }) => pressed && styles.pressed} onPress={guardarEstudiante}>
              <ThemedView type="backgroundSelected" style={styles.saveButton}>
                <ThemedText type="small" style={styles.saveButtonText}>
                  {guardando ? 'Guardando…' : 'Guardar producto'}
                </ThemedText>
              </ThemedView>
            </Pressable>

            <Pressable style={({ pressed }) => pressed && styles.pressed} onPress={() => setModalVisible(false)}>
              <ThemedView style={styles.cancelButton}>
                <ThemedText type="small" themeColor="textSecondary">
                  Cancelar
                </ThemedText>
              </ThemedView>
            </Pressable>
          </ThemedView>
        </View>
      </Modal>
    </ThemedView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    flexDirection: 'row',
  },
  safeArea: {
    flex: 1,
    paddingHorizontal: Spacing.four,
    alignItems: 'center',
    gap: Spacing.three,
    paddingBottom: BottomTabInset + Spacing.three,
    maxWidth: MaxContentWidth,
  },
  header: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: Spacing.three,
    paddingVertical: Spacing.four,
    alignSelf: 'stretch',
  },
  newProductButton: {
    paddingVertical: Spacing.two,
    paddingHorizontal: Spacing.three,
    borderRadius: Spacing.three,
    alignItems: 'center',
  },
  emptyText: {
    textAlign: 'center',
    marginTop: Spacing.five,
  },
  listContent: {
    alignSelf: 'stretch',
    gap: Spacing.three,
    paddingBottom: Spacing.four,
  },
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: Spacing.three,
    padding: Spacing.three,
    borderRadius: Spacing.three,
  },
  cardInfo: {
    flex: 1,
    gap: Spacing.half,
  },
  cardActions: {
    flexDirection: 'row',
    gap: Spacing.two,
    alignItems: 'center',
  },
  editButton: {
    paddingVertical: Spacing.two,
    paddingHorizontal: Spacing.three,
    borderRadius: Spacing.two,
    alignItems: 'center',
  },
  editButtonText: {
    fontWeight: '700',
  },
  deleteButton: {
    backgroundColor: '#EF4444',
    paddingVertical: Spacing.two,
    paddingHorizontal: Spacing.three,
    borderRadius: Spacing.two,
    alignItems: 'center',
  },
  deleteButtonText: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  pressed: {
    opacity: 0.7,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: Spacing.four,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalCard: {
    alignSelf: 'stretch',
    maxWidth: MaxContentWidth,
    gap: Spacing.three,
    padding: Spacing.four,
    borderRadius: Spacing.four,
  },
  field: {
    gap: Spacing.two,
  },
  input: {
    borderWidth: 1,
    borderColor: 'transparent',
    borderRadius: Spacing.two,
    paddingVertical: Spacing.two,
    paddingHorizontal: Spacing.three,
    fontSize: 16,
  },
  saveButton: {
    paddingVertical: Spacing.three,
    paddingHorizontal: Spacing.four,
    borderRadius: Spacing.three,
    alignItems: 'center',
  },
  saveButtonText: {
    fontWeight: '700',
  },
  cancelButton: {
    paddingVertical: Spacing.two,
    paddingHorizontal: Spacing.four,
    borderRadius: Spacing.three,
    alignItems: 'center',
  },
});
